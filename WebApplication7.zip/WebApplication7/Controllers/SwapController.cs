﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication7.Controllers
{
    public class SwapController : Controller
    {
        // GET: Swap
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(FormCollection o)
        {
            String a,b, temp;
            a= o["txtnum1"].ToString();
            b = o["txtnum2"].ToString();
            temp = a;
            a = b;
            b = temp;
            ViewBag.Result = "a=" + a + " b=" + b;
            return View();
        }
    }
}