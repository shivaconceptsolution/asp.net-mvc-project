﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication5.Controllers
{
    public class AdditionController : Controller
    {
        // GET: Addition
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(String txtnum1,String txtnum2)
        {
            int a = int.Parse(txtnum1);
            int b = int.Parse(txtnum2);
            ViewBag.data = a + b;
            return View();
        }
    }
}