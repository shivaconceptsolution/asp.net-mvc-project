﻿using System.Web.Mvc;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(SI obj)
        {
            ViewBag.Result = "Result is " + (obj._p * obj._r * obj._t) / 100;

            return View();
        }

        public ActionResult Aboutus()
        {

            return View("Index");
        }

        public ActionResult Contactus()
        {
            return View();

        }
    }
}