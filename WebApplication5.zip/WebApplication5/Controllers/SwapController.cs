﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication5.Controllers
{
    public class SwapController : Controller
    {
        // GET: Swap
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(FormCollection obj)
        {
            int a = Convert.ToInt32(obj["txtnum1"].ToString());
            int b = Convert.ToInt32(obj["txtnum2"].ToString());
            int c;
            c = a;
            a = b;
            b = c;
            ViewBag.data = "Result is " + a + " " + b;
            return View();
        }
    }
}